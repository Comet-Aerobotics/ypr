// generated from rosidl_generator_c/resource/idl.h.em
// with input from rosapi_msgs:msg/TypeDef.idl
// generated code does not contain a copyright notice

#ifndef ROSAPI_MSGS__MSG__TYPE_DEF_H_
#define ROSAPI_MSGS__MSG__TYPE_DEF_H_

#include "rosapi_msgs/msg/detail/type_def__struct.h"
#include "rosapi_msgs/msg/detail/type_def__functions.h"
#include "rosapi_msgs/msg/detail/type_def__type_support.h"

#endif  // ROSAPI_MSGS__MSG__TYPE_DEF_H_
