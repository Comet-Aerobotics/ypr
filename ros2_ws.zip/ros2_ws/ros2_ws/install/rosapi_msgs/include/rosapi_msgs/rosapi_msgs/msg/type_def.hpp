// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROSAPI_MSGS__MSG__TYPE_DEF_HPP_
#define ROSAPI_MSGS__MSG__TYPE_DEF_HPP_

#include "rosapi_msgs/msg/detail/type_def__struct.hpp"
#include "rosapi_msgs/msg/detail/type_def__builder.hpp"
#include "rosapi_msgs/msg/detail/type_def__traits.hpp"
#include "rosapi_msgs/msg/detail/type_def__type_support.hpp"

#endif  // ROSAPI_MSGS__MSG__TYPE_DEF_HPP_
