// generated from rosidl_generator_c/resource/idl.h.em
// with input from rosbridge_msgs:msg/ConnectedClient.idl
// generated code does not contain a copyright notice

#ifndef ROSBRIDGE_MSGS__MSG__CONNECTED_CLIENT_H_
#define ROSBRIDGE_MSGS__MSG__CONNECTED_CLIENT_H_

#include "rosbridge_msgs/msg/detail/connected_client__struct.h"
#include "rosbridge_msgs/msg/detail/connected_client__functions.h"
#include "rosbridge_msgs/msg/detail/connected_client__type_support.h"

#endif  // ROSBRIDGE_MSGS__MSG__CONNECTED_CLIENT_H_
