// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROSBRIDGE_MSGS__MSG__CONNECTED_CLIENT_HPP_
#define ROSBRIDGE_MSGS__MSG__CONNECTED_CLIENT_HPP_

#include "rosbridge_msgs/msg/detail/connected_client__struct.hpp"
#include "rosbridge_msgs/msg/detail/connected_client__builder.hpp"
#include "rosbridge_msgs/msg/detail/connected_client__traits.hpp"
#include "rosbridge_msgs/msg/detail/connected_client__type_support.hpp"

#endif  // ROSBRIDGE_MSGS__MSG__CONNECTED_CLIENT_HPP_
