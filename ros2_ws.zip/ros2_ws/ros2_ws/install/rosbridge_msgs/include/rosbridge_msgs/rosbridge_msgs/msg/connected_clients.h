// generated from rosidl_generator_c/resource/idl.h.em
// with input from rosbridge_msgs:msg/ConnectedClients.idl
// generated code does not contain a copyright notice

#ifndef ROSBRIDGE_MSGS__MSG__CONNECTED_CLIENTS_H_
#define ROSBRIDGE_MSGS__MSG__CONNECTED_CLIENTS_H_

#include "rosbridge_msgs/msg/detail/connected_clients__struct.h"
#include "rosbridge_msgs/msg/detail/connected_clients__functions.h"
#include "rosbridge_msgs/msg/detail/connected_clients__type_support.h"

#endif  // ROSBRIDGE_MSGS__MSG__CONNECTED_CLIENTS_H_
