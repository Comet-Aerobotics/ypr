

#include <cstdint>
#include <iostream>


#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/vector3.hpp"

#include "HAL/Timer.hpp"
#include "Interface/Errors.hpp"
#include "Interface/Sensor.hpp"
#include "Interface/Registers.hpp"

using namespace VN;

std::string usage = "[port]\n";

int main(int argc, char* argv[])
{

    // [ROS 2 Addition] Init ROS 2
    rclcpp::init(argc, argv);

    // [ROS 2 Addition] Create a node and a publisher
    auto node = std::make_shared<rclcpp::Node>("vector_node_minimal");
    auto publisher = node->create_publisher<geometry_msgs::msg::Vector3>("vector_ypr", 10);
    // 2. Poll and print the model number using a read register command
    // 3. Poll and print the current yaw, pitch, and roll using a read register command
    // 4. Configure the ADOR and ADOF to YPR at 2Hz
    // 5. Configure the first binary output to output timeStartup, accel, and angRate, all from common group, with a 200 rate divisor
    // 6. Enter a loop for 5 seconds where it:
    //    Determines which measurement it received (VNYPR or the necessary binary header)
    //    Prints out the relevant measurement from the CD struct
    // 7. Disconnect from sensor

    // Define the port connection parameters to be used later
    const std::string portName = (argc > 1) ? argv[1] : "COM33";  // Change the sensor port name to the comm port of your local machine

    // [1] Instantiate a sensor object we'll use to interact with the sensor, and connect to the unit
    Sensor sensor;
    Error latestError = sensor.autoConnect(portName);
    //VN::Registers::System::BaudRate(Baud1115200);
    if (latestError != Error::None)
    {
        std::cout << "Error " << latestError << " encountered when connecting to " + portName << ".\t" << std::endl;
        return static_cast<int>(latestError);
    }
    std::cout << "Connected to " << portName << " at " << sensor.connectedBaudRate().value() << std::endl;

    // [2] Read and print the sensor model number
    // Create an empty register object of the necessary type, where the data member will be populated when the sensor responds to our "read register" request
    Registers::System::Model modelRegister;

    latestError = sensor.readRegister(&modelRegister);
    if (latestError != Error::None)
    {
        std::cout << "Error" << latestError << " encountered when reading register " << modelRegister.id() << " (" << modelRegister.name() << ")" << std::endl;
        return static_cast<int>(latestError);
    }
    std::string modelNumber = modelRegister.model;
    std::cout << "Sensor Model Number: " << modelNumber << std::endl;

    // [3] Read and print the current YPR
    Registers::Attitude::YawPitchRoll yprRegister;
    latestError = sensor.readRegister(&yprRegister);
    if (latestError != Error::None)
    {
        std::cout << "Error" << latestError << " encountered when reading register " << yprRegister.id() << " (" << yprRegister.name() << ")" << std::endl;
        return static_cast<int>(latestError);
    }
    
    std::cout << "Current Reading:  Yaw - " 
    << yprRegister.yaw << " , Pitch - " << yprRegister.pitch 
    << " , Roll - " << yprRegister.roll << std::endl;
    
    // [4] Configure the asynchronous ASCII output to YPR at 2Hz
    Registers::System::AsyncOutputType asyncDataOutputType;
    asyncDataOutputType.ador = Registers::System::AsyncOutputType::Ador::YPR;
    asyncDataOutputType.serialPort = Registers::System::AsyncOutputType::SerialPort::Serial1;
    latestError = sensor.writeRegister(&asyncDataOutputType);
    if (latestError != Error::None)
    {
        std::cout << "Error" << latestError << " encountered when configuring register " << asyncDataOutputType.id() << " (" << asyncDataOutputType.name()
                  << ")" << std::endl;
        return static_cast<int>(latestError);
    }
    else { std::cout << "ADOR configured\n"; }

    Registers::System::AsyncOutputFreq asyncDataOutputFrequency;
    asyncDataOutputFrequency.adof=Registers::System::AsyncOutputFreq::Adof::Rate4Hz; asyncDataOutputFrequency.serialPort=Registers::System::AsyncOutputFreq::SerialPort::Serial1;
    latestError = sensor.writeRegister(&asyncDataOutputFrequency);
    if (latestError != Error::None)
    {
        std::cout << "Error" << latestError << " encountered when configuring register " << asyncDataOutputFrequency.id() << " ("
                  << asyncDataOutputFrequency.name() << ")" << std::endl;
        return static_cast<int>(latestError);
    }
    else { std::cout << "ADOF configured\n"; }

    // [5] Configure the binary output to 4 Hz through both serial ports, with specified outputs
    Registers::System::BinaryOutput1 binaryOutput1Register;
    binaryOutput1Register.ins = true;
    binaryOutput1Register.rateDivisor = 400;
    binaryOutput1Register.asyncMode.serial1 = true;
    binaryOutput1Register.asyncMode.serial2 = true;
    binaryOutput1Register.common.timeStartup = true;
    //binaryOutput1Register.common.posLla = false;
    binaryOutput1Register.common.velNed = true;
    binaryOutput1Register.common.accel = true;
    // Explicit Diabling of GPS, GNSS, and Magnetometer in common union
    binaryOutput1Register.common.magPres = false;
    binaryOutput1Register.common.timeGps = false;
    binaryOutput1Register.common.imu = false;
    binaryOutput1Register.common.timeGpsPps = false;
    
    
    
    latestError = sensor.writeRegister(&binaryOutput1Register);
    if (latestError != Error::None)
    {
        std::cout << "Error" << latestError << " encountered when configuring register " << binaryOutput1Register.id() << " (" << binaryOutput1Register.name()
                  << ")" << std::endl;
        return static_cast<int>(latestError);
    }
    else { std::cout << "Binary output 1 message configured.\n"; }

    // [6] Listen to measurements from the sensor and print recognized packets
    while (true)
    {
        Sensor::CompositeDataQueueReturn compositeData = sensor.getNextMeasurement();
        sensor.readRegister(&yprRegister);
        // Check to make sure that a measurement is available
        if (!compositeData) continue;

        if (compositeData->matchesMessage(binaryOutput1Register))
        {
           continue;
                      
        }
    	else if(compositeData -> matchesMessage("VNYPR")) {
	    
	    Ypr ypr = compositeData -> attitude.ypr.value();
	    #include <iomanip>  // for std::setw, std::setprecision

	  std::cout << "\rYaw: " << std::fixed << std::setprecision(2) << 
	  std::setw(6) << ypr.yaw
          << "  Pitch: " << std::setw(6) << ypr.pitch
          << "  Roll: "  << std::setw(6) << ypr.roll << " "
          << std::flush;

	    
	    }
	    
	else {
	 std::cout << "Unrecognized asynchronous message received.\n";
	 }
	 
	 geometry_msgs::msg::Vector3 msg;
           msg.x = yprRegister.yaw;
           msg.y = yprRegister.pitch;
           msg.z = yprRegister.roll;
           publisher->publish(msg);

         // [ROS 2 Addition] Handle any pending ROS 2 callbacks
         // (If you are not subscribing or using services, this can be omitted or left as is.)
         rclcpp::spin_some(node);

        // Sleep briefly or yield, so we don't chew 100% CPU 
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
	}

    // [7] Disconnect from the sensor
    sensor.disconnect();
    std::cout << "Sensor disconnected.\n";
}
